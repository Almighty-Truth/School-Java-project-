/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package challenge3;
import java.util.Date;
import java.util.Comparator;
/**
 *
 * @author Student
 */
public class SortPetArray {
    static Pet[] SortByVaccinationDate(Pet[] listOfPets) {
        int n = listOfPets.length;
        for (int i = 0; i < n - 1; i++) {

            for (int j = 0; j < n - i - 1; j++) {
                if (Long.compare(listOfPets[j].getUnixDate(),
                        listOfPets[j+1].getUnixDate()) > 0) {
                    // swap listOfPets[j+1] and listOfPets[j]
                    Pet temp = listOfPets[j];
                    listOfPets[j] = listOfPets[j + 1];
                    listOfPets[j + 1] = temp;
                } 
            }
        }
            return listOfPets;

        }
    
   static Pet[] SortByAge(Pet[] listOfPets) {
        int n = listOfPets.length;
        for (int i = 0; i < n - 1; i++) {

            for (int j = 0; j < n - i - 1; j++) {
                if (Long.compare(listOfPets[j].getAge(),
                        listOfPets[j+1].getAge()) > 0) {
                    // swap listOfPets[j+1] and listOfPets[j]
                    Pet temp = listOfPets[j];
                    listOfPets[j]= listOfPets[j+1];
                    listOfPets[j + 1] = temp;
                } 
            }
        }
            return listOfPets;

        }
}
