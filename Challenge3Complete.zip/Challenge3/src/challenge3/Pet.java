/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package challenge3;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author Student
 */
public class Pet {

    private String species;
    private int age;

    private String ownerLastName;
    private String ownerFirstName;
    private String ownerEmail;
    private String petName;
    private int YearOfVaccine;
    private int MonthOfVaccine;
    private int DayOfVaccine;

    public Pet(String species, int age, String ownerLastName,
            String ownerFirstName, String ownerEmail, String petName,
            int YearOfVaccine, int MonthOfVaccine, int DayOfVaccine) {
        this.species = species;
        this.age = age;
        this.ownerLastName = ownerLastName;
        this.ownerFirstName = ownerFirstName;
        this.ownerEmail = ownerEmail;
        this.petName = petName;
        this.YearOfVaccine = YearOfVaccine;
        this.MonthOfVaccine = MonthOfVaccine;
        this.DayOfVaccine = DayOfVaccine;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getPetName() {
        return petName;
    }

    public void setPetName(String petName) {
        this.petName = petName;
    }

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }

    public int getYearOfVaccine() {
        return YearOfVaccine;
    }

    public void setYearOfVaccine(int YearOfVaccine) {
        this.YearOfVaccine = YearOfVaccine;
    }

    public int getMonthOfVaccine() {
        return MonthOfVaccine;
    }

    public void setMonthOfVaccine(int MonthOfVaccine) {
        this.MonthOfVaccine = MonthOfVaccine;
    }

    public int getDayOfVaccine() {
        return DayOfVaccine;
    }

    public void setDayOfVaccine(int DayOfVaccine) {
        this.DayOfVaccine = DayOfVaccine;
    }

    public long getUnixDate() {
        LocalDate day = LocalDate.of(YearOfVaccine, MonthOfVaccine, DayOfVaccine);
        return day.toEpochDay();
    }

    public String getFormatDate() {
        LocalDate day = LocalDate.of(YearOfVaccine, MonthOfVaccine, DayOfVaccine);
        DateTimeFormatter DateFormat = DateTimeFormatter.ofPattern("yyyy/MM/dd");

        return day.format(DateFormat);
    }

    public String getownerFirstName() {
        return ownerFirstName;
    }

    public void setOwnerFirstName(String ownerFirstName) {
        this.ownerFirstName = ownerFirstName;
    }

    public String getownerLastName() {
        return ownerLastName;
    }

    public void setOwnerLastName(String ownerLastName) {
        this.ownerLastName = ownerLastName;
    }

    public String getownerEmail() {
        return ownerEmail;
    }

    public void setownerEmail(String ownerEmail) {
        this.ownerEmail = ownerEmail;
    }

    @Override
    public String toString() {

        return ownerFirstName + " " + ownerLastName + ", your pet named " + petName + " was last vaccinated on " + getFormatDate();
                
    }

}
