/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package challenge3;

/**
 *
 * @author Student
 */
import java.io.File;
import java.io.FileNotFoundException;
//import java.time.LocalDate;
//import java.time.format.DateTimeFormatter;
//import java.util.ArrayList;
import java.util.Arrays;
//import java.util.Comparator;
import java.util.Scanner;
import challenge3.Pet;
//import challenge3.SortPetArray;

public class Challenge3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Pet[] myPets = CreateArrayOfPets();

        PrintByAge(SortPetArray.SortByAge(myPets));
        PrintByVaccine(SortPetArray.SortByVaccinationDate(myPets));
        printArray(myPets);
    }

   
    public static Pet[] CreateArrayOfPets() { //declare this as an array Pet[] myPets = new Pet[10];
         Pet[] petsList = {};
         int petcount = 0;

        try {
            String userDirectory = new File("").getAbsolutePath();

            File file = new File(userDirectory + "\\src\\challenge3\\pet_records.txt");
            Scanner scanner = new Scanner(file);
            
            while(scanner.hasNextLine())
            {
                String line = scanner.nextLine().strip();
                if (line.isBlank()!= true)
                {
                    petcount++;
                }
            }
            scanner.close();
            
            petsList = new Pet[petcount];
            Scanner scanner2 = new Scanner(file);
            for(int i = 0; i< petcount; i++) 
            {
                String line = scanner2.nextLine().strip();
               
                if (line.isBlank() != true) {
                    
                    
               
                String[] fields = line.split("\\s+");
               
                String petName = fields[0];
                
                String species = fields[1];
                int age = Integer.parseInt(fields[2]);
                int year = Integer.parseInt(fields[3]);
                int month = Integer.parseInt(fields[4]);
                int day = Integer.parseInt(fields[5]);
                String ownerLastName = fields[6];
                String ownerFirstName = fields[7];
                String ownerEmail = fields[8];

                Pet pet = new Pet(species, age, ownerLastName,
                        ownerFirstName, ownerEmail, petName, year,
                        month, day);
                petsList[i] = pet;

                }

            }
            scanner2.close();
            
        } catch (FileNotFoundException e) {
            System.out.println();
            e.printStackTrace();
        }

        return petsList; //returns array in place of arrayList

    }

    public static void PrintByAge(Pet[] arrayOfPets) {

        // Print the youngest and oldest pets
        Pet youngestPet = arrayOfPets[0];
        Pet oldestPet = arrayOfPets[arrayOfPets.length - 1];

        System.out.println("the youngest pet is:" + youngestPet.getPetName() + ", a feline owned by Hernandez Yvette");
        System.out.println("Oldest pet is:  " + oldestPet.getPetName() + ", a canine owned by smith, john");
    }

    public static void PrintByVaccine(Pet[] arrayOfPets) {

        Pet lastVaccinated = arrayOfPets[arrayOfPets.length - 1];
        String vaccinationDate = lastVaccinated.getFormatDate();
        System.out.println(lastVaccinated.getownerFirstName() + ", your pet named "
                + lastVaccinated.getPetName() + " was last vaccinated on "
                + vaccinationDate);
    }

    public static void printArray(Pet[] petArray) {
        for (Pet pet : petArray) {
            System.out.println(pet.toString());
        }
    }

}
